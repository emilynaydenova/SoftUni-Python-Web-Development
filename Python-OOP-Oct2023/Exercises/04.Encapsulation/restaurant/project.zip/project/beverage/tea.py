from project.beverage.hot_beverage import HotBeverage


class Tea(HotBeverage):
    pass
