from django.contrib import admin

# Register your models here.
from notes_app.models import Note, Profile


@admin.register(Note)
class NoteAdmin(admin.ModelAdmin):
    list_display = ['title','profile']
    list_filter = ['profile']


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
      list_display = ['full_name','age']
