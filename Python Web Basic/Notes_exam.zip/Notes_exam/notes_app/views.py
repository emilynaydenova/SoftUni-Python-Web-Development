from django.shortcuts import render, redirect

from notes_app.forms import ProfileForm, NoteForm
from notes_app.models import Note, Profile


def home(request):
    is_profile_exists = Profile.objects.exists()
    if not is_profile_exists:
        return redirect('create profile')

    notes = Note.objects.all()

    context = {
        'notes': notes,
    }
    return render(request, 'home-with-profile.html', context)


def add_note(request):
    if request.method == 'GET':
        context = {
            'form': NoteForm(),
        }
        return render(request, 'note-create.html', context)

    else:
        form = NoteForm(request.POST)
        if form.is_valid():
            note = form.save(commit=False)
            note.profile = Profile.objects.first()
            note.save()
            return redirect('home')
        else:
            context = {
                'form': form,
            }
            return render(request, "note-create.html", context)


def edit_note(request, pk):
    note = Note.objects.get(pk=pk)

    if request.method == "GET":
        context = {
            'note': note,
            'form': NoteForm(instance=note),
        }
        return render(request, 'note-edit.html', context)

    else:
        form = NoteForm(request.POST, instance=note)

        if form.is_valid():
            note = form.save(commit=False)
            note.profile = Profile.objects.first()
            note.save()
            return redirect('home')

        context = {
            'note': note,
            'form': form,
        }
        return render(request, 'note-edit.html', context)


def delete_note(request, pk):
    note = Note.objects.get(pk=pk)
    if request.method == "GET":
        form = NoteForm(instance=note)

        for (_, field) in form.fields.items():
            field.widget.attrs['disabled'] = True

        context = {
            'form': form,
        }
        return render(request, 'note-delete.html', context)
    else:
        note.delete()
        return redirect('home')


def details_note(request, pk):
    note = Note.objects.get(pk=pk)
    context = {
        'note': note,
    }
    return render(request, 'note-details.html', context)


def show_profile(request):
    profile = Profile.objects.first()

    context = {
        'profile': profile,
        'count': profile.note_set.count()
    }
    return render(request, "profile.html", context)


def create_profile(request):
    if request.method == 'GET':
        context = {
            'form': ProfileForm(),
        }
        return render(request, 'home-no-profile.html', context)
    else:
        form = ProfileForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
        else:
            context = {
                'form': form,
            }
            return render(request, "home-no-profile.html", context)


def delete_profile(request):
    profile = Profile.objects.first()
    if request.method == "GET":
        return render(request, 'profile-delete.html')
    else:
        profile.delete()
        # notes will be deleted because of FK to Profile
        return redirect('home')
